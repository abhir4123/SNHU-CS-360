package com.example.projecttwo;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

// This activity serves as the login and account creation screen for the app.
public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101; // Unique code to track permission result
    private EditText editTextUsername, editTextPassword;
    private Button buttonLogin, buttonSignUp;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // Loads the login screen layout

        // Initialize input fields and buttons
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonSignUp = findViewById(R.id.buttonSignUp);

        // Initialize the database helper for user validation
        dbHelper = new DatabaseHelper(this);

        // Handle login button click
        buttonLogin.setOnClickListener(view -> {
            String username = editTextUsername.getText().toString();
            String password = editTextPassword.getText().toString();

            // Validate credentials with database
            if (dbHelper.validateUser(username, password)) {
                Toast.makeText(MainActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MainActivity.this, InventoryActivity.class));
            } else {
                Toast.makeText(MainActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        });

        // Handle sign-up button click
        buttonSignUp.setOnClickListener(view -> {
            String username = editTextUsername.getText().toString();
            String password = editTextPassword.getText().toString();

            // Enforce non-empty username
            if (username.isEmpty()) {
                Toast.makeText(this, "Username cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }

            // Enforce minimum password length
            if (password.length() < 8) {
                Toast.makeText(this, "Password must be at least 8 characters", Toast.LENGTH_SHORT).show();
                return;
            }

            // Try to insert new user into database
            if (dbHelper.insertUser(username, password)) {
                requestSmsPermission(); // Prompt SMS permission on successful signup
                Toast.makeText(MainActivity.this, "Signup Successful!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MainActivity.this, InventoryActivity.class));
            } else {
                Toast.makeText(MainActivity.this, "User already exists", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Requests SEND_SMS permission from the user
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        }
    }

    // Callback to handle user response to SMS permission request
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
