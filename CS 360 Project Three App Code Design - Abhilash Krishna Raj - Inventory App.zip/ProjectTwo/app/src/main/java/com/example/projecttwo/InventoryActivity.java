package com.example.projecttwo;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText editItemName, editItemQuantity;
    private GridLayout gridLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Inventory App");
        setContentView(R.layout.activity_inventory);

        // Initialize views
        editItemName = findViewById(R.id.editItemName);
        editItemQuantity = findViewById(R.id.editItemQuantity);
        gridLayout = findViewById(R.id.gridLayoutItems);
        Button buttonAddItem = findViewById(R.id.buttonAddItem);
        Button buttonLogout = findViewById(R.id.buttonLogout);

        dbHelper = new DatabaseHelper(this);
        displayItems();

        // Handle item addition
        buttonAddItem.setOnClickListener(v -> {
            String name = editItemName.getText().toString().trim();
            String qtyText = editItemQuantity.getText().toString().trim();

            if (name.isEmpty() || qtyText.isEmpty()) {
                Toast.makeText(this, "Please enter item name and quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            int qty = Integer.parseInt(qtyText);
            dbHelper.insertItem(name, qty);
            displayItems();
            editItemName.setText("");
            editItemQuantity.setText("");

            // Send alert if low or out of stock
            if (qty <= 5) {
                sendLowInventorySmsAlert(name, qty);
            }

            Toast.makeText(this, "Item added successfully!", Toast.LENGTH_SHORT).show();
        });

        // Handle logout
        buttonLogout.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }

    // Fetch and display items from database
    private void displayItems() {
        gridLayout.removeAllViews();
        Cursor cursor = dbHelper.getAllItems();

        addGridRow("Item Name", "Quantity", "Action", true);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
                int qty = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_QTY));
                addGridRow(name, String.valueOf(qty), "Delete", false, id);
            } while (cursor.moveToNext());
        }

        cursor.close();
    }

    // Add a single row to the inventory grid
    private void addGridRow(String itemName, String qty, String action, boolean isHeader, int... itemId) {
        GridLayout.LayoutParams layoutParams;

        // Column 1: Item Name
        TextView itemView = new TextView(this);
        itemView.setText(itemName);
        itemView.setPadding(8, 8, 8, 8);
        layoutParams = new GridLayout.LayoutParams();
        layoutParams.width = 0;
        layoutParams.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        itemView.setLayoutParams(layoutParams);

        // Column 2: Quantity
        TextView qtyView = new TextView(this);
        qtyView.setText(qty);
        qtyView.setPadding(8, 8, 8, 8);
        layoutParams = new GridLayout.LayoutParams();
        layoutParams.width = 0;
        layoutParams.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        qtyView.setLayoutParams(layoutParams);

        // Column 3: Action buttons or header
        LinearLayout actionLayout = new LinearLayout(this);
        actionLayout.setOrientation(LinearLayout.HORIZONTAL);
        layoutParams = new GridLayout.LayoutParams();
        layoutParams.width = 0;
        layoutParams.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 2f); // extra width for two buttons
        actionLayout.setLayoutParams(layoutParams);
        actionLayout.setPadding(4, 4, 4, 4);

        if (!isHeader) {
            // Update Button
            Button updateBtn = new Button(this);
            updateBtn.setText("Update");
            updateBtn.setOnClickListener(v -> showUpdateDialog(itemId[0]));
            actionLayout.addView(updateBtn);

            // Delete Button
            Button deleteBtn = new Button(this);
            deleteBtn.setText(action);
            deleteBtn.setOnClickListener(v -> {
                dbHelper.deleteItem(itemId[0]);
                displayItems();
                Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
            });
            actionLayout.addView(deleteBtn);
        } else {
            // Header Label
            TextView header = new TextView(this);
            header.setText(action);
            header.setPadding(8, 8, 8, 8);
            actionLayout.addView(header);
        }

        gridLayout.addView(itemView);
        gridLayout.addView(qtyView);
        gridLayout.addView(actionLayout);
    }

    // Pop-up dialog for updating item quantity
    private void showUpdateDialog(int itemId) {
        EditText inputQty = new EditText(this);
        inputQty.setHint("Enter new quantity");
        inputQty.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        new AlertDialog.Builder(this)
                .setTitle("Update Quantity")
                .setView(inputQty)
                .setPositiveButton("Update", (dialog, which) -> {
                    String qtyText = inputQty.getText().toString().trim();
                    if (!qtyText.isEmpty()) {
                        int newQty = Integer.parseInt(qtyText);
                        dbHelper.updateItem(itemId, newQty);
                        displayItems();

                        if (newQty <= 5) {
                            Cursor c = dbHelper.getAllItems();
                            if (c.moveToFirst()) {
                                do {
                                    int id = c.getInt(c.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
                                    if (id == itemId) {
                                        String itemName = c.getString(c.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
                                        sendLowInventorySmsAlert(itemName, newQty);
                                        break;
                                    }
                                } while (c.moveToNext());
                                c.close();
                            }
                        }

                        Toast.makeText(this, "Quantity updated", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Sends an SMS alert if SMS permission is granted and quantity is low
    private void sendLowInventorySmsAlert(String itemName, int quantity) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            String phoneNumber = "5551234567"; // Replace with a real or test number
            String message;

            if (quantity == 0) {
                message = "ALERT: '" + itemName + "' is OUT OF STOCK.";
            } else {
                message = "Low Inventory Alert: '" + itemName + "' has only " + quantity + " left.";
            }

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS alert sent", Toast.LENGTH_SHORT).show();
        }
    }
}
